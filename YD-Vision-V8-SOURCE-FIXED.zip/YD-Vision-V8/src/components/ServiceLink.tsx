
import type {MouseEvent,ReactNode} from 'react';
export default function ServiceLink({service,children,className=''}:{service:string;children:ReactNode;className?:string}){
 function select(e:MouseEvent<HTMLAnchorElement>){
  e.preventDefault();window.dispatchEvent(new CustomEvent('yd:service',{detail:service}));document.querySelector('#contact')?.scrollIntoView({behavior:window.matchMedia('(prefers-reduced-motion: reduce)').matches?'auto':'smooth'});
 }
 return <a href="#contact" onClick={select} className={className}>{children}</a>
}
