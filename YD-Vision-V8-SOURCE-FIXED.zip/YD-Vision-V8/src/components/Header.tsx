
import {AnimatePresence,motion,useReducedMotion} from 'motion/react';
import {useEffect,useState} from 'react';
import {useLocation, useNavigate} from 'react-router-dom';
import {Globe,Menu,X,ArrowUpRight} from 'lucide-react';
import {type Copy,type Locale,locales} from '@/lib/i18n';
const ids=['services','work','formats','process','reviews'] as const;
const labels=['navServices','navWork','navFormats','navProcess','navReviews'] as const;
export default function Header({t,locale}:{t:Copy;locale:Locale}){
 const [open,setOpen]=useState(false),navigate=useNavigate(),location=useLocation(),reduced=useReducedMotion();
 useEffect(()=>{document.documentElement.lang=locale},[locale]);
 function change(value:Locale){navigate(`/${value}${location.hash||''}`);setOpen(false)}
 return <><div className="announcement"><span className="ann-dot"/>{t.ann}<span className="ml-auto opacity-65 hidden sm:block">YD / DEMO—08</span></div><header className="site-header"><div className="container header-inner"><a className="brand" href="#top" aria-label="YD Vision Home"><span className="brand-mark">Y<span className="brand-d">D<span className="eye-dot"/></span></span><span className="brand-name">YD <b>VISION</b><small>VISUAL DESIGN STUDIO</small></span></a><nav className="nav desktop-nav" aria-label={t.footerExplore}>{ids.map((id,i)=><a key={id} href={`#${id}`}>{t[labels[i]]}</a>)}</nav><div className="header-actions"><label className="language-control"><Globe size={17} aria-hidden="true"/><span className="sr-only">{t.language}</span><select value={locale} onChange={e=>change(e.target.value as Locale)} aria-label={t.language} className="lang-select">{locales.map(l=><option value={l} key={l}>{l==='kk'?'ҚАЗ':l.toUpperCase()}</option>)}</select></label><a href="#contact" className="btn btn-dark header-cta">{t.navContact}<ArrowUpRight size={15}/></a><button className="menu-button" onClick={()=>setOpen(v=>!v)} aria-expanded={open} aria-controls="mobile-nav" aria-label={t.menuToggle}>{open?<X/>:<Menu/>}</button></div></div><AnimatePresence initial={false}>{open&&<motion.nav initial={reduced?false:{height:0,opacity:0}} animate={{height:'auto',opacity:1}} exit={{height:0,opacity:0}} transition={{duration:reduced?0:.3}} id="mobile-nav" className="mobile-nav" aria-label={t.footerExplore}>{ids.map((id,i)=><a href={`#${id}`} key={id} onClick={()=>setOpen(false)}><span>0{i+1}</span>{t[labels[i]]}<ArrowUpRight size={18}/></a>)}<a href="#contact" onClick={()=>setOpen(false)}>{t.navContact}<ArrowUpRight size={18}/></a></motion.nav>}</AnimatePresence></header></>;
}
