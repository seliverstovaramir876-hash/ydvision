import {Rich,type Copy} from '@/lib/i18n';
import Reveal from './Reveal';
export default function SectionHeading({eyebrow,title,description,dark=false}:{eyebrow:string;title:string;description?:string;dark?:boolean}){
 return <div className={`section-head ${dark?'light':''}`}><Reveal><div className="eyebrow"><i className="line"/>{eyebrow}</div><h2><Rich value={title}/></h2></Reveal>{description&&<Reveal delay={.12}><p className="section-desc">{description}</p></Reveal>}</div>;
}
