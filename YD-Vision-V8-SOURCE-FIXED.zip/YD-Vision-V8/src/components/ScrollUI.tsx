
import {motion,useScroll,useReducedMotion} from 'motion/react';
import {useEffect,useState} from 'react';
import {ArrowUp} from 'lucide-react';
import type {Copy,Locale} from '@/lib/i18n';
export default function ScrollUI({t,locale}:{t:Copy,locale:Locale}){const {scrollYProgress}=useScroll();const reduced=useReducedMotion();const [visible,setVisible]=useState(false);
 useEffect(()=>{const onScroll=()=>setVisible(window.scrollY>650);window.addEventListener('scroll',onScroll,{passive:true});onScroll();return()=>window.removeEventListener('scroll',onScroll)},[]);
 return <><motion.div className="top-progress" style={{scaleX:scrollYProgress}} aria-hidden="true"/>{visible&&<button aria-label={t.backToTop} className="back-top" onClick={()=>window.scrollTo({top:0,behavior:reduced?'auto':'smooth'})}><ArrowUp size={19}/></button>}</>}
