
import {motion,useReducedMotion} from 'motion/react';
import type {ReactNode} from 'react';
export default function Reveal({children,delay=0,className=''}:{children:ReactNode;delay?:number;className?:string}){
 const reduced=useReducedMotion();
 return <motion.div className={className} initial={reduced?false:{opacity:0,y:25}} whileInView={{opacity:1,y:0}} viewport={{once:true,amount:0.13}} transition={{duration:reduced?0:.65,delay:reduced?0:delay,ease:[.22,1,.36,1]}}>{children}</motion.div>;
}
