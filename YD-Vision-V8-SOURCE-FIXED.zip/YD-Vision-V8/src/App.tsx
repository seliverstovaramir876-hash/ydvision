import { useEffect } from 'react';
import { Navigate, Route, Routes, useLocation, useParams } from 'react-router-dom';
import { getCopy, isLocale, type Locale } from '@/lib/i18n';
import Header from '@/components/Header';
import Footer from '@/sections/Footer';
import Hero from '@/sections/Hero';
import Services from '@/sections/Services';
import Formats from '@/sections/Formats';
import Portfolio from '@/sections/Portfolio';
import Comparison from '@/sections/Comparison';
import Manifesto from '@/sections/Manifesto';
import Process from '@/sections/Process';
import About from '@/sections/About';
import FAQ from '@/sections/FAQ';
import Reviews from '@/sections/Reviews';
import Contact from '@/sections/Contact';
import ScrollUI from '@/components/ScrollUI';
function LocalePage() {
 const { locale: param } = useParams();
 const location = useLocation();
 const locale = isLocale(param ?? '') ? (param as Locale) : null;
 useEffect(()=>{
   if (!locale) return;
   document.documentElement.lang=locale;
   const t=getCopy(locale);
   document.title=`${t.pageTitle} — Demo`;
   const meta=document.querySelector('meta[name="description"]');meta?.setAttribute('content',t.heroLead);
 },[locale]);
 useEffect(()=>{
   if(!locale) return;
   if(location.hash) requestAnimationFrame(()=>document.getElementById(decodeURIComponent(location.hash.slice(1)))?.scrollIntoView({behavior:'instant'}));
   else window.scrollTo({top:0,behavior:'instant'});
 },[location.pathname,location.hash]);
 if(!locale) return <Navigate to="/ru" replace/>;
 const t=getCopy(locale);
 return <><a href="#main" className="skip-link">{t.skip}</a><ScrollUI locale={locale} t={t}/><Header locale={locale} t={t}/><main id="main"><Hero t={t}/><Services t={t}/><Formats t={t}/><Portfolio t={t} locale={locale}/><Comparison t={t}/><Manifesto t={t}/><Process t={t}/><About t={t}/><FAQ t={t}/><Reviews t={t}/><Contact t={t}/></main><Footer t={t} locale={locale}/></>;
}
function NotFound(){return <main style={{minHeight:'100vh',display:'grid',placeItems:'center',background:'#101b29',color:'#fff',padding:24}}><div><span>YD / VISION</span><h1 style={{fontSize:96}}>404.</h1><p>Page not found / Страница не найдена / Бет табылмады</p><a href="/ru" style={{display:'inline-block',borderBottom:'1px solid #a2bbeb',marginTop:25,paddingBottom:8}}>← YD Vision</a></div></main>}
export default function App(){return <Routes><Route path="/" element={<Navigate to="/ru" replace/>}/><Route path="/:locale" element={<LocalePage/>}/><Route path="*" element={<NotFound/>}/></Routes>}
