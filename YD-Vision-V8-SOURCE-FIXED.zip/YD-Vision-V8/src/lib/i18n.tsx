import ru from '@/locales/ru.json';
import en from '@/locales/en.json';
import kk from '@/locales/kk.json';
import type { ReactNode } from 'react';

export const locales = ['ru', 'en', 'kk'] as const;
export type Locale = typeof locales[number];
const dictionaries = { ru, en, kk } as const;
export type Copy = typeof ru;
export const isLocale = (value: string): value is Locale => locales.includes(value as Locale);
export const getCopy = (locale: Locale): Copy => dictionaries[locale] as unknown as Copy;
export const words = (copy: Copy, key: keyof Copy) => copy[key] ?? key;

/** Renders only <em> and <br> tokens from our version-controlled translation JSON, never raw HTML. */
export function richTokens(source: string): Array<{value: string; kind: 'text'|'em'|'break'}> {
  const chunks = source.split(/(<br\s*\/?\s*>|<em>.*?<\/em>)/gi).filter(Boolean);
  return chunks.map(chunk => /^<br/i.test(chunk) ? {value:'',kind:'break' as const} :
    /^<em>/i.test(chunk) ? {value:chunk.slice(4,-5),kind:'em' as const} : {value:chunk,kind:'text' as const});
}
export function Rich({value}: {value: string}): ReactNode {
  return richTokens(value).map((chunk,index) => chunk.kind === 'break' ? <br key={index}/> : chunk.kind === 'em' ? <em key={index}>{chunk.value}</em> : <span key={index}>{chunk.value}</span>);
}
