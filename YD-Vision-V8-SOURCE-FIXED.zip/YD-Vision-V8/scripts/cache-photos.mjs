/** Optional one-time fetch of the six existing Pexels source images.
 * Changes the source file to reference local JPEGs ONLY after all six downloads succeed.
 * Pexels authors and source links remain in src/data/projects.ts.
 */
import {readFile,writeFile,mkdir,rename,rm} from 'node:fs/promises';
import path from 'node:path';
const file='src/data/projects.ts';
let src=await readFile(file,'utf8');
const re=/photo:'(https:\/\/images\.pexels\.com\/photos\/([0-9]+)\/[^']+)'/g;
const matches=[...src.matchAll(re)];
if(matches.length===0){console.log('Local references already configured (or no Pexels images found).');process.exit(0)}
if(matches.length!==6)throw new Error(`Expected 6 original images, found ${matches.length}`);
await mkdir('public/images',{recursive:true});
const files=[];
try{
 for(let i=0;i<matches.length;i++){
  const [full,url,id]=matches[i];
  const response=await fetch(url,{signal:AbortSignal.timeout(25000)});
  if(!response.ok||!response.headers.get('content-type')?.startsWith('image/'))throw new Error(`Not an image or server error: ${url} (${response.status})`);
  const bytes=Buffer.from(await response.arrayBuffer());
  if(bytes.length<10000||bytes.length>8000000)throw new Error(`Unexpected image size: ${id}, ${bytes.length}`);
  const target=`/images/pexels-${id}.jpg`;
  const temp=path.join('public',target+'.download').replace('public/','public/');
  await writeFile(temp,bytes);files.push({temp,dest:path.join('public',target)});
  src=src.replace(full,`photo:'${target}'`);
  console.log(`${i+1}/6 ${id}: ${bytes.length} bytes`);
 }
 for(const {temp,dest} of files) await rename(temp,dest);
 await writeFile(file,src);
 console.log('All six original photos stored locally and source references updated. Retained photographer and source credits.');
}catch(error){for(const {temp} of files)await rm(temp,{force:true});throw error}
